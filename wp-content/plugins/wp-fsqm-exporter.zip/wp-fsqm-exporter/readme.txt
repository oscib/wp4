=== Exporter for FSQM Pro ===
Contributors: swashata, akash
Donate link: N/A
Tags: feedback, survey, form, web-form, database form, quiz, opinion
Requires at least: 3.5
Tested up to: 3.6
License: GPLv3

Extends WP Feedback, Survey & Quiz Manager Pro plugin to add the ability to export reports to XLSX, PDF, HTML XLS and/ or submissions to CSV files.

== Description ==

Please check the online documentation http://ipanelthemes.com/fsqm-exporter-doc/#!/documenter_cover

== Developer's Notes ==
Items below are vaguley documented or not documented at all.
The reason for this is, we haven't released any of the APIs publicly and we will not
until we have them completely. Till then, if you wish to do something with them,
feel free to experiment. Also check the source code to learn more about them.

=== APIS (Undocumented) ===
ipt_fsqm_exp_exports_deleted - Hook
ipt_fsqm_exp_raws_deleted - Hook
