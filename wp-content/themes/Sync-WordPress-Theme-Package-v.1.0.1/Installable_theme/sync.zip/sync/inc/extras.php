<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package Sync
 */

// custom style
function iwebtheme_build_custom_css(){
		$iwebtheme_buildcss = '';
		$iwebtheme_buildcss .= iwebtheme_option_css();
		$iwebtheme_buildcss .= iwebtheme_custom_css();
		$iwebtheme_buildcss .= iwebtheme_meta_css();


		if(!empty($iwebtheme_buildcss)){
			$iwebtheme_wrap_buildcss ='';
			$iwebtheme_wrap_buildcss .="<style type=\"text/css\">\n";
			$iwebtheme_wrap_buildcss .= $iwebtheme_buildcss;
			$iwebtheme_wrap_buildcss .="</style>\n";
			echo $iwebtheme_wrap_buildcss;
		}
}
add_action('wp_head','iwebtheme_build_custom_css'); 

// get custom css from theme options
function iwebtheme_option_css(){	
	global $redux_iwebtheme;
	$setting_css = '';
	
	$iwebtheme_opt_footerbg = $redux_iwebtheme['opt-color-footerbg'];
	//typography
	$iwebtheme_opt_headingfamily = $redux_iwebtheme['opt-typography-heading']['font-family'];
	$iwebtheme_opt_headingweight = $redux_iwebtheme['opt-typography-heading']['font-weight'];
	
	$iwebtheme_opt_bodyfamily = $redux_iwebtheme['opt-typography-body']['font-family'];
	$iwebtheme_opt_bodyweight = $redux_iwebtheme['opt-typography-body']['font-weight'];

	
	//home intro
	$iwebtheme_intro_bg_color= $redux_iwebtheme['intro-bg-color'];
	$iwebtheme_intro_bg_image  = $redux_iwebtheme['intro-bg-image']['url'];


		if($iwebtheme_opt_footerbg != '#1c1c1c') {
			$setting_css .= "#footer {";
			$setting_css .= "background-color: ".$iwebtheme_opt_footerbg.";";
			$setting_css .= "}";
		}


		if($iwebtheme_opt_headingfamily != '') {
			$setting_css .= "h1,h2,h3,h4,h5,h6 {";
			$setting_css .= "font-family: ".$iwebtheme_opt_headingfamily.",sans-serif;";
			$setting_css .= "}";		
		}
		if($iwebtheme_opt_headingweight != '400') {
			$setting_css .= "h1,h2,h3,h4,h5,h6 {";
			$setting_css .= "font-weight: ".$iwebtheme_opt_headingweight.";";
			$setting_css .= "}";		
		}
		
		if($iwebtheme_opt_bodyfamily != '') {
			$setting_css .= "body {";
			$setting_css .= "font-family: ".$iwebtheme_opt_bodyfamily.",sans-serif;";
			$setting_css .= "}";		
		}
		
		if($iwebtheme_opt_bodyweight != '') {
			$setting_css .= "body {";
			$setting_css .= "font-weight: ".$iwebtheme_opt_bodyweight.";";
			$setting_css .= "}";		
		}

		
		if($iwebtheme_intro_bg_image != '') {
			$setting_css .= "#home {";
			$setting_css .= "background: url(".$iwebtheme_intro_bg_image.") center center;\n";
			$setting_css .= "background-position: center center;";
			$setting_css .= "-moz-background-size: cover;";
			$setting_css .= "-o-background-size: cover;";
			$setting_css .= "background-size: cover;";
			$setting_css .= "position: relative;";
			$setting_css .= "height: auto;";
			$setting_css .= "overflow: hidden;";
			$setting_css .= "}";
		}
		
		if($iwebtheme_intro_bg_color != '') {
			$setting_css .= "#home {";
			$setting_css .= "background-color: ".$iwebtheme_intro_bg_color." !important;\n";
			$setting_css .= "}";
		}

		
		
	return $setting_css;
}

// get custom css from custom css in theme options
function iwebtheme_custom_css(){	
	global $redux_iwebtheme;
	$setting_css = '';
	$iwebtheme_customcss = $redux_iwebtheme['opt-custom-css'];

	
	$iwebtheme_opt_headingfamily = $redux_iwebtheme['opt-typography-heading']['font-family'];
	$iwebtheme_opt_headingweight = $redux_iwebtheme['opt-typography-heading']['font-weight'];
	
	
		if($iwebtheme_customcss != '') {
			$setting_css .= $iwebtheme_customcss;
		}

		
	return $setting_css;
}

// get custom css from section meta 
function iwebtheme_meta_css(){
	global $post;
	
	$home_section_query = new WP_Query( array( 'post_type' => 'homepagesection', 'posts_per_page' => -1, 'order' => 'ASC' ) ); 
		
		$meta_css = '';
		$featimage = '';

		if($home_section_query->have_posts()): while($home_section_query->have_posts()) : $home_section_query->the_post();

			//get meta values
			if ( function_exists( 'rwmb_meta' ) ) :
			$section_bgimg_vpos = get_post_meta($post->ID, 'iweb_section_bgimg_vpos', TRUE);
			$section_bgimg_hpos = get_post_meta($post->ID, 'iweb_section_bgimg_hpos', TRUE);
			$section_bgimg = rwmb_meta( 'iweb_section_bgimg', 'type=plupload_image' );
			foreach ( $section_bgimg as $image )
			{
				$sectionbg = $image['full_url'];
			}
			
			
			endif;

			// assign ID and class to section
			$homesec_class = ".".get_post_type()."-".$post->post_name."";
			$homesec_id = $post->post_name;
			
			//header lp type
			if ( function_exists( 'rwmb_meta' ) ) :
			if(!empty($section_bgimg)){
				$meta_css .= "#".$homesec_id." {\n";
				$meta_css .= "background-image: url(".$sectionbg.");\n";
				$meta_css .= "background-position: ".$section_bgimg_hpos." ".$section_bgimg_vpos.";";
				$meta_css .= "background-repeat: no-repeat;";
				$meta_css .= "background-size: cover;";
				$meta_css .= "display:block;";
				$meta_css .= "position:relative;";
				$meta_css .= "}";
			}
			
			endif;
			
			endwhile;
			wp_reset_postdata();
			return $meta_css."\n\n";

		endif;
}

/*============================================
Sort page section
============================================= */
if ( ! function_exists( 'iwebtheme_sort_sections' ) ){

	function iwebtheme_sort_sections(){
		if(!has_nav_menu( 'main' )){
			return;
		}
		if ( ( $locations = get_nav_menu_locations() ) && isset( $locations['main'] ) ) {		

			$menu = wp_get_nav_menu_object( $locations['main'] );
			$items  = wp_get_nav_menu_items($menu->term_id);
			$sections = array();

			foreach((array) $items as $key => $menu_items){
				if('homepagesection' == $menu_items->object){
					$sections[] = $menu_items->object_id;
				}
			}
			return $sections;
		}
	}
}

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function sync_body_classes( $classes ) {
	// Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	return $classes;
}
add_filter( 'body_class', 'sync_body_classes' );

//cust js
function iwebtheme_custom_js(){
	$script_out = '';
	$script_out .= '<script>'."\n";
	$script_out .= 'jQuery(document).ready(function($){'."\n";
	$script_out .= iwebtheme_sync_header();
	$script_out .= '});'."\n";
	$script_out .= "\n".'</script>'."\n\n\n";

	echo $script_out;
}

add_action('wp_footer','iwebtheme_custom_js',100);


function iwebtheme_sync_header() {
	$script = '';
	$script .= "$('body #header').addClass('header-visible');"."\n";
	$script .= "$('body.page-template-page-home-php #header').removeClass('header-visible');"."\n";
	$script .= "$(window).scroll(function () {"."\n";
	$script .= "var scaleBg = -$(window).scrollTop() / 10;"."\n";  
	$script .= "if ($(window).scrollTop() > 1) {"."\n"; 
	$script .= "$('body.page-template-page-home-php #header').addClass('header-visible');"."\n";	
	$script .= "} else {"."\n";
	$script .= "$('body.page-template-page-home-php #header').removeClass('header-visible');"."\n";
	$script .= "}"."\n";
	$script .= "});"."\n";
return $script;
}


function sync_post_nav() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}

	?>
	<nav class="navigation post-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'twentyfourteen' ); ?></h1>
		<div class="nav-links">
			<?php
			if ( is_attachment() ) :
				previous_post_link( '%link', __( '<span class="meta-nav">Published In</span>%title', 'twentyfourteen' ) );
			else :
				previous_post_link( '%link', __( '<span class="meta-nav">Previous Post</span>%title', 'twentyfourteen' ) );
				next_post_link( '%link', __( '<span class="meta-nav">Next Post</span>%title', 'twentyfourteen' ) );
			endif;
			?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}


/**
 * Filters wp_title to print a neat <title> tag based on what is being viewed.
 *
 * @param string $title Default title text for current view.
 * @param string $sep Optional separator.
 * @return string The filtered title.
 */
function sync_wp_title( $title, $sep ) {
	if ( is_feed() ) {
		return $title;
	}

	global $page, $paged;

	// Add the blog name
	$title .= get_bloginfo( 'name', 'display' );

	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) ) {
		$title .= " $sep $site_description";
	}

	// Add a page number if necessary:
	if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
		$title .= " $sep " . sprintf( __( 'Page %s', 'iwebtheme' ), max( $paged, $page ) );
	}

	return $title;
}
add_filter( 'wp_title', 'sync_wp_title', 10, 2 );

/**
 * Sets the authordata global when viewing an author archive.
 *
 * This provides backwards compatibility with
 * http://core.trac.wordpress.org/changeset/25574
 *
 * It removes the need to call the_post() and rewind_posts() in an author
 * template to print information about the author.
 *
 * @global WP_Query $wp_query WordPress Query object.
 * @return void
 */
function sync_setup_author() {
	global $wp_query;

	if ( $wp_query->is_author() && isset( $wp_query->post ) ) {
		$GLOBALS['authordata'] = get_userdata( $wp_query->post->post_author );
	}
}
add_action( 'wp', 'sync_setup_author' );
?>
<?php
// tag
 $args = array(
'smallest' => 8,
'largest' => 22,
'unit' => 'pt',
'number' => 45,
'format' => 'flat',
'separator' => '\\"\n\\"',
'orderby' => 'name',
'order' => 'ASC',
'exclude' => null,
'include' => null,
'link' => 'view',
'taxonomy' => 'post_tag',
'echo' => true,
'child_of' => null
);

add_filter('widget_tag_cloud_args','set_number_tags');
function set_number_tags($args) {
$args = array('smallest' => 11, 'largest' => 11);
return $args;
}

//pagination
function pagination($pages = '', $range = 1)
{
     $showitems = ($range * 2)+1; 
 
     global $paged;
     if(empty($paged)) $paged = 1;
 
     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }  
 
     if(1 != $pages)
     {
         echo "<ul class=\"pagination\">";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link(1)."'>&laquo;</a></li>";
         if($paged > 1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a></li>";
 
         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<li><a href=\"#\" class=\"active\">".$i."</a></li>":"<li><a href='".get_pagenum_link($i)."'>".$i."</a></li>";
             }
         }
 
         if ($paged < $pages && $showitems < $pages) echo "<li><a href=\"".get_pagenum_link($paged + 1)."\">&rsaquo;</a></li>";
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<li><a href='".get_pagenum_link($pages)."'>&raquo;</a></li>";
         echo "</ul>\n";
     }
}

//avatar
add_filter('get_avatar','change_avatar_css');

function change_avatar_css($class) {
$class = str_replace("class='avatar", "class='img-circle ", $class) ;
return $class;
}


function custom_comments($comment, $args, $depth) {
$GLOBALS['comment'] = $comment; ?>
	<li id="comment-<?php comment_ID() ?>">
		<div class="comment">
			<div class="comment-top">
				<?php echo get_avatar($comment,$size='80'); ?>
				<ul class="comment-meta">
					<li class="date"><?php echo get_comment_date(); ?></li>
					<li class="author"><?php echo __('By', 'iwebtheme'); ?> <?php echo get_the_author(); ?></li>
					<li class="reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></li>
				</ul>
			</div>

		<?php if ($comment->comment_approved == '0') : ?>
							<em><?php _e('Your comment is awaiting moderation.', 'iwebtheme') ?></em>
						<?php endif; ?>	
			<div class="comment-content">
				<?php comment_text() ?>	
			</div>
		</div>
<?php
} ?>