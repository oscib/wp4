<?php
/**
 * Rapid meta boxes - require 'Meta box' plugin
 */
$prefix = 'iweb_';

global $meta_boxes;

$meta_boxes = array();

/* =========================================*/
// Homesection meta

$meta_boxes[] = array(
	'id' => 'sectionoptions',
	'title' => 'Home page section heading',
	'pages' => array( 'homepagesection' ),
	'context' => 'normal',
	'priority' => 'high',

	// List of meta fields
	'fields' => array(
		array(
				'name'		=> 'Custom section title',
				'id'		=> $prefix . "section_title",
				'type'		=> 'text',
				'std'		=> '',
				'desc'		=> 'Enter your Section title',
		),
		array(
				'name'		=> 'Section sub title',
				'id'		=> $prefix . "section_subtitle",
				'type'		=> 'textarea',
				'std'		=> '',
				'desc'		=> 'Short paragraph of description under title',
		),	

		array(
				'name' => __( 'Disable section heading on frontend', 'rwmb' ),
				'id'   => "{$prefix}section_disableheading",
				'type' => 'checkbox',
				// Value can be 0 or 1
				'desc'         => 'Check to disable section heading on frontend', 
				'std'  => 0,
		),
	)
);

$meta_boxes[] = array(
	'id' => 'sectionstyleoptions',
	'title' => 'Customize home page section styling',
	'pages' => array( 'homepagesection' ),
	'context' => 'normal',
	'priority' => 'high',

	// List of meta fields
	'fields' => array(
	
		array(
			'name'     => 'Section background',
			'id'       => "{$prefix}section_bg",
			'type'     => 'select_advanced',
			// Array of 'value' => 'Label' pairs for select box
			'options'  => array(
				'white-bg' => __( 'White', 'rwmb' ),
				'grey-bg' => __( 'Grey', 'rwmb' ),
			),
			// Select multiple values, optional. Default is false.
			'multiple'    => false,
			'std'         => 'white-bg',
			'placeholder' => __( 'Select section background color', 'rwmb' ),
		),

		array(
			'name'     => 'Padding bottom',
			'id'       => "{$prefix}section_paddbottom",
			'type'     => 'select_advanced',
			// Array of 'value' => 'Label' pairs for select box
			'options'  => array(
				'offsetBottomL' => __( 'Padding', 'rwmb' ),
				'nooffsetBottomL' => __( 'No Padding', 'rwmb' ),
			),
			// Select multiple values, optional. Default is false.
			'multiple'    => false,
			'std'         => 'offsetBottomL',
			'placeholder' => __( 'Select padding behavior', 'rwmb' ),
		),
		array(
				'name' => 'Add background image',
				'id'   => "{$prefix}section_bgimg",
				'type' => 'plupload_image',
				'desc' => 'Upload image',
				'max_file_uploads' => 1,
				'std' => '',
		),
		array(
			'name'     => 'Background image position (horizontal)',
			'id'       => "{$prefix}section_bgimg_hpos",
			'type'     => 'select_advanced',
			// Array of 'value' => 'Label' pairs for select box
			'options'  => array(
				'left' => __( 'Left', 'rwmb' ),
				'right' => __( 'Right', 'rwmb' ),
				'center' => __( 'Center', 'rwmb' ),
			),
			// Select multiple values, optional. Default is false.
			'multiple'    => false,
			'std'         => 'center',
			'placeholder' => __( 'Select background image position', 'rwmb' ),
		),
		array(
			'name'     => 'Background image position (vertical)',
			'id'       => "{$prefix}section_bgimg_vpos",
			'type'     => 'select_advanced',
			// Array of 'value' => 'Label' pairs for select box
			'options'  => array(
				'top' => __( 'Top', 'rwmb' ),
				'bottom' => __( 'Bottom', 'rwmb' ),
				'center' => __( 'Center', 'rwmb' ),
			),
			// Select multiple values, optional. Default is false.
			'multiple'    => false,
			'std'         => 'bottom',
			'placeholder' => __( 'Select background image position', 'rwmb' ),
		),
		array(
				'name' => __( 'Add dark background overlay', 'rwmb' ),
				'id'   => "{$prefix}section_overlay",
				'type' => 'checkbox',
				// Value can be 0 or 1
				'desc'         => 'Check to enable section overlay', 
				'std'  => 0,
		),
	
	)
);


// ================================== end page meta box

/* =========================================*/
// Portfolio meta
/* =========================================*/

$meta_boxes[] = array(
	'id'		=> 'portfolio_slides',
	'title'		=> 'Portfolio item detail',
	'pages'		=> array( 'portfolio' ),
	'context' => 'normal',

	'fields'	=> array(
	
		array(
				'name'		=> 'Portfolio item description',
				'id'		=> $prefix . "portfolio_desc",
				'type'		=> 'textarea',
				'std'		=> '',
				'desc'		=> 'Write your portfolio description',
		),
	
	)
);


// ============================================= *//

/* =========================================*/
// Testimonial meta
/* =========================================*/
$meta_boxes[] = array(
	'id' => 'synctestimonial_meta',
	'title' => 'Testimonial detail',
	'pages' => array( 'sync_testimonial'),
	'context' => 'normal',
	'priority' => 'high',

	// List of meta fields	
	'fields' => array(
		array(
				'name'		=> 'Name',
				'id'		=> $prefix . "test_author",
				'type'		=> 'text',
				'std'		=> '',
				'desc'		=> 'Testimonial author',
		),
		array(
				'name'		=> 'Comment',
				'id'		=> $prefix . "test_comment",
				'type'		=> 'textarea',
				'std'		=> '',
				'desc'		=> 'Testimonial from author',
		),
		array(
				'name'		=> 'Info',
				'id'		=> $prefix . "test_info",
				'type'		=> 'text',
				'std'		=> '',
				'desc'		=> 'Client info, e,g job role and website',
		),

	)
);

/* =========================================*/
// Page meta
/* =========================================*/



/********************* META BOX REGISTERING ***********************/

/**
 * Register meta boxes
 *
 * @return void
 */
function iwebtheme_register_meta_boxes()
{
	// Make sure there's no errors when the plugin is deactivated or during upgrade
	if ( !class_exists( 'RW_Meta_Box' ) )
		return;

	global $meta_boxes;
	foreach ( $meta_boxes as $meta_box )
	{
		new RW_Meta_Box( $meta_box );
	}
}
// Hook to 'admin_init' to make sure the meta box class is loaded before
// (in case using the meta box class in another plugin)
// This is also helpful for some conditionals like checking page template, categories, etc.
add_action( 'admin_init', 'iwebtheme_register_meta_boxes' );