<?php
/**
 * Rapid functions and definitions
 *
 * @package Sync
 */


/**
 * Add Redux Framework & extras
 */
global $redux_iwebtheme;
require get_template_directory() . '/admin/admin-init.php';


/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 1170; /* pixels */
}

if ( ! function_exists( 'sync_setup' ) ) :
function sync_setup() {

	load_theme_textdomain( 'iwebtheme', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );
	/* --- post image functionality --- */
	add_theme_support( 'post-thumbnails' );

if ( function_exists( 'add_image_size' ) ) {
	add_image_size( 'full-size',  9999, 9999, false );
	add_image_size( 'small-thumb',  54, 54, true );
}

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'main' => __( 'Main Menu', 'iwebtheme' ),
		'footer' => __( 'Footer Menu', 'iwebtheme' ),
	) );
	/* --- Filters --- */
	add_filter('widget_text', 'do_shortcode');
	add_filter('template_redirect', 'iwebtheme_page_section_redirect');
	add_filter( 'wp_nav_menu_objects', 'iwebtheme_single_page_nav_links' );
	add_filter('nav_menu_css_class', 'nav_class_filter', 10, 2);

	add_filter('nav_menu_css_class' , 'active_nav_class' , 10 , 2);

	
	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'audio', 'gallery','quote', 'link' ) );
	add_editor_style( 'css/editor-style.css' );
	// Setup the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'sync_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif; // sync_setup
add_action( 'after_setup_theme', 'sync_setup' );


/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function sync_widgets_init() {
	register_sidebar(array(
			'name' => 'Primary Sidebar',
			'id'   => 'primary-sidebar',
			'description'   => 'These are widgets for primary sidebar.',
			'before_widget' => '<div class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3>',
			'after_title'   => '</h3>'
	));
}
add_action( 'widgets_init', 'sync_widgets_init' );



// Reduce nav classes, leaving only 'current-menu-item'
function nav_class_filter( $var ) {
	return is_array($var) ? array_intersect($var, array('current-menu-item')) : '';
}

function active_nav_class($classes, $item){
     if( in_array('current-menu-item', $classes) ){
             $classes[] = 'active ';
     }
     return $classes;
}



function iwebtheme_page_section_redirect(){
	global $wp;

	if(is_404()){
		if(isset($wp->query_vars["homepagesection"])){
			wp_redirect(home_url('/#').$wp->query_vars["name"]);
		}		
	}
}

function iwebtheme_single_page_nav_links( $items ) {
	foreach ( $items as $item ) {
		if('homepagesection' == $item->object){
			$current_post = get_post($item->object_id);
			$menu_title = "#".$current_post->post_name;
				if(is_page_template('page-home.php')) {
					$item->url = $menu_title;
				} else {
					$item->url = home_url( '/' ).$menu_title;
				}
		} else if('custom' == $item->type && !is_home()){
			if( 1 === preg_match('/^#([^\/]+)$/', $item->url , $matches)){			 	
			 	$item->url = home_url( '/' ).$item->url;
			}
		}	 
	}
	return $items;   
}

/**
 * Enqueue scripts and styles.
 */
function sync_scripts() {
global $redux_iwebtheme;
	wp_enqueue_style('bootstrap', get_template_directory_uri(). '/css/bootstrap.css', 'style');
	wp_enqueue_style( 'sync-style', get_template_directory_uri(). '/style.css', 'style');
	wp_enqueue_style('responsive', get_template_directory_uri(). '/css/responsive.css', 'style');
	wp_enqueue_style('font-awesome', get_template_directory_uri(). '/css/font-awesome.css', 'style');
	wp_enqueue_style('owl-carousel', get_template_directory_uri(). '/css/owl.carousel.css', 'style');
	wp_enqueue_style('animate', get_template_directory_uri(). '/css/animate.css', 'style');

	
	if (!class_exists('ReduxFramework')) {
	wp_enqueue_style('skin', get_template_directory_uri(). '/css/colors/color-concrete.css', 'style');
	} else {
	$iwebtheme_pre_css = $redux_iwebtheme['opt-select-stylesheet'];
	wp_enqueue_style('skin', get_template_directory_uri(). '/css/colors/'.$iwebtheme_pre_css, 'style');
	}


	
	wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/js/modernizr.js','jquery', true );
	wp_enqueue_script( 'jquery', get_template_directory_uri() . '/js/jquery.min.js', 'jquery',true );

	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js','jquery', '1.0.0', true );
	wp_enqueue_script( 'nivo-lightbox', get_template_directory_uri() . '/js/nivo-lightbox.js','jquery', '1.0.0', true );

	wp_enqueue_script( 'owl.carousel', get_template_directory_uri() . '/js/owl.carousel.js','jquery','1.0.0', true );

	wp_enqueue_script( 'skrollr', get_template_directory_uri() . '/js/skrollr.min.js','jquery', '1.0.0', true );
	wp_enqueue_script( 'smoothscroll', get_template_directory_uri() . '/js/smoothscroll.js','jquery','1.0.0', true );
	wp_enqueue_script( 'localscroll', get_template_directory_uri() . '/js/jquery.localscroll.min.js','jquery', '1.0.0', true );
	wp_enqueue_script( 'scrollTo', get_template_directory_uri() . '/js/jquery.scrollTo.min.js','jquery', '1.0.0', true );
	wp_enqueue_script( 'wow', get_template_directory_uri() . '/js/wow.min.js','jquery','1.0.0', true );
	wp_enqueue_script( 'main', get_template_directory_uri() . '/js/main.js','jquery','1.0.0', true );

	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'sync_scripts' );

/* require */
require get_template_directory() . '/inc/aq_resizer.php';
require get_template_directory() . '/inc/sync_navwalker.php';
require get_template_directory() . '/inc/extras.php';
require get_template_directory() . '/inc/sync-meta.php';
