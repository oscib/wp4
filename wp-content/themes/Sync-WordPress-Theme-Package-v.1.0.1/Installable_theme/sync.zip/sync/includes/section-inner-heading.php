<section class="intro-inner featured page-blog">
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="section-heading">
					<?php get_template_part('includes/breadcrumbs'); ?>
					</div>

				</div>
			</div>
		</div>
	
    </section>
	<!-- /Section: intro -->