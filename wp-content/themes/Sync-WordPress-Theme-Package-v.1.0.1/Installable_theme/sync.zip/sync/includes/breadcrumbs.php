<?php function get_breadcrumbs()
{
    global $wp_query;
    if ( !is_home() ){
        // Start the UL
		echo '<a href="'. home_url() .'">'. 'Home ' .'</a>';
        // Add the Home link
        if ( is_category() )
        {
            $catTitle = single_cat_title( "", false );
            $cat = get_cat_ID( $catTitle );
			echo ' &#47;&nbsp; ';
            echo get_category_parents( $cat, TRUE, " " );
        }
        elseif ( is_archive() && !is_category() )
        {
            echo '  &#47;&nbsp; '.__('Archives','iwebtheme').'';
        }
        elseif ( is_search() ) {
 
            echo '  &#47;&nbsp; '.__('Search Results','iwebtheme').'';
        }
        elseif ( is_404() )
        {
            echo ' &#47;&nbsp; '.__('404 Not Found','iwebtheme').'';
        }
		
        elseif ( is_singular( 'portfolio' ) )
        {
			echo '  &#47;&nbsp; ';
            echo the_title('','', FALSE) ."";
        }
		
        elseif ( is_single() )
        {
		
            $categories = get_the_category();
			$category_id ='';
			foreach($categories as $category) {
				if ($category->cat_name!== 'broder') {
					$category_id = get_cat_ID( $category->cat_name );
				}
			}
			echo '  &#47;&nbsp; ';
			if (!empty($category_id)) {
            echo get_category_parents( $category_id, TRUE, '  &#47;&nbsp; ' );
			}
            echo the_title('','', FALSE) ." ";
        }


        elseif ( is_page() )
        {
            $post = $wp_query->get_queried_object();
 
            if ( $post->post_parent == 0 ){
 
                echo ' &#47;&nbsp; '.the_title('','', FALSE).'';
 
            } else {
                $title = the_title('','', FALSE);
                $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
                array_push($ancestors, $post->ID);
 
                foreach ( $ancestors as $ancestor ){
                    if( $ancestor != end($ancestors) ){
                        echo ' &#47;&nbsp; <a href="'. get_permalink($ancestor) .'">'. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</a>';
                    } else {
                        echo ' &#47;&nbsp; '. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'';
                    }
                }
            }
        }
        // End the UL
    }
}
?>
<?php
return get_breadcrumbs();
?>