<?php
global $redux_iwebtheme;
if (!empty($_SERVER['SCRIPT_FILENAME']) && 'section-home.php' == basename($_SERVER['SCRIPT_FILENAME'])){
	die ('This file can not be accessed directly!');
}
?>
<?php 
global $tmp_post;
$page_type = get_post_meta($post->ID, 'iweb_section_type', TRUE); 
?>
<?php get_template_part('includes/section-default'); ?>
