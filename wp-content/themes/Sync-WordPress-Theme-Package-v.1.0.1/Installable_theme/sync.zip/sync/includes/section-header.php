<?php
global $redux_iwebtheme;
?>    
	<div class="inner offsetBottomL offsetTopL" data-0="top: 200px; opacity: 1;" data-450="top: 370px; opacity:0;">
            <div class="container">
                <div class="row">

                    <div class="col-sm-7 text-center content-right">

                        <!-- start main logo -->
						<?php if($redux_iwebtheme['lp-logo']['url'] != '') { ?>
                        <h1 id="logo">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                <img src="<?php echo $redux_iwebtheme['lp-logo']['url']; ?>" width="<?php echo $redux_iwebtheme['lp-logo-w']; ?>" height="<?php echo $redux_iwebtheme['lp-logo-h']; ?>" alt="" title="" />
                            </a>
                        </h1>
						<?php } else { ?>
						<h1 id="logo">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/img/logo@2x.png" width="175" height="70" alt="" title="" />
                            </a>
                        </h1>
						<?php } ?>
                        <!-- end main logo -->
						<?php
						$counter = 0;
						if($redux_iwebtheme['intro-lptitle'][0] != '') { ?>
						<div class="big-text">
                            <ul id="text-rotator" class="owl-carousel owl-theme">
						<?php 
						foreach($redux_iwebtheme['intro-lptitle'] as $slide) { 
							 ?>
							<li><span><?php echo $redux_iwebtheme['intro-lptitle'][$counter]; ?></span></li>
						<?php $counter++; }	?>
						</ul>
                        </div>
						<?php } ?>

						<?php if($redux_iwebtheme['intro-subtitle'] != '') { ?>
                        <div class="small-text">
                            <span>
                                <?php echo $redux_iwebtheme['intro-subtitle']; ?>
                            </span>
                        </div>
						<?php } ?>

                        <div class="home-buttons">
							<?php if($redux_iwebtheme['intro-button1'] != '') { ?>
                            <a href="<?php echo $redux_iwebtheme['intro-button1']; ?>" class="btn btn-primary btn-lg"><?php echo $redux_iwebtheme['intro-button1-txt']; ?></a>
							<?php } ?>
							<?php if($redux_iwebtheme['intro-button2'] != '') { ?>
                            <a href="<?php echo $redux_iwebtheme['intro-button2']; ?>" class="btn btn-subscribe-home btn-lg"><?php echo $redux_iwebtheme['intro-button2-txt']; ?></a>
							<?php } ?>
						</div>

                        <ul class="os">
						<?php if($redux_iwebtheme['intro-os1'] != '') { ?>
                            <li><a href="<?php echo $redux_iwebtheme['intro-os1']; ?>" data-toggle="tooltip" data-original-title="App Store"><i class='fa fa-apple'></i></a></li>
                        <?php } ?>   
						<?php if($redux_iwebtheme['intro-os2'] != '') { ?>						
							<li><a href="<?php echo $redux_iwebtheme['intro-os2']; ?>" data-toggle="tooltip" data-original-title="Android Market"><i class='fa fa-android'></i></a></li>
                        <?php } ?>       
						<?php if($redux_iwebtheme['intro-os3'] != '') { ?>	
							<li><a href="<?php echo $redux_iwebtheme['intro-os3']; ?>" data-toggle="tooltip" data-original-title="Windows Mobile"><i class='fa fa-windows'></i></a></li>
                        <?php } ?>   
						</ul>
                    </div>

                    <div class="col-sm-5">
					<?php if($redux_iwebtheme['intro-product-image']['url'] != '') { ?>
                        <img src="<?php echo $redux_iwebtheme['intro-product-image']['url']; ?>" class="img-responsive" alt="" />
					<?php } ?>
                    </div>

                </div>
            </div>
        </div>