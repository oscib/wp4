<?php 
global $wpdb, $post, $homesec_class;
$section_bg = get_post_meta($post->ID, 'iweb_section_bg', TRUE);
$section_paddbottom = get_post_meta($post->ID, 'iweb_section_paddbottom', TRUE);
$section_title = get_post_meta($post->ID, 'iweb_section_title', TRUE);
$section_subtitle = get_post_meta($post->ID, 'iweb_section_subtitle', TRUE);
$section_disableheading = get_post_meta($post->ID, 'iweb_section_disableheading', TRUE);
$section_overlay = get_post_meta($post->ID, 'iweb_section_overlay', TRUE);
?>
<section id="<?php echo $post->post_name;?>" class="home-section home-<?php echo $post->ID;?> <?php echo $homesec_class; ?>-<?php echo $post->post_name;?> offsetTopL <?php echo $section_paddbottom;?> <?php echo $section_bg;?>" >
<?php if ($section_overlay !=0) { ?>
<div class="section-overlay"></div>
<?php } ?>	
	<div class="container">	
		
		<?php if ($section_disableheading !=1) { ?>
			<div class="row section-head offsetBottomL text-center">
					<?php if ($section_title != '') { ?>
						<h2><?php echo $section_title; ?></h2>
						<?php } else { ?>
						<h2><?php the_title(); ?></h2>
						<?php } ?>
						<?php if ($section_subtitle != '') { ?>
						<p><?php echo $section_subtitle; ?></p>
						<?php } ?>
					<hr class="head-separator" />
			</div>
		<?php } ?>	
		
		<div class="row">
			<div class="col-md-12">
					<?php the_content(); ?>
			</div>
		</div>
	</div>
</section>