<?php
/**
 * @package WordPress
 * @subpackage Sync Theme
 */
?>
<form class="search-form" action="<?php echo home_url(); ?>">
		<input type="text" name="s" id="s" placeholder="<?php echo __('Type and enter','iwebtheme'); ?>" class="form-control input-md" />		
</form>

