<?php
global $redux_iwebtheme;
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package Sync
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <!-- start preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>
    <!-- end preloader -->

		
    <!-- start home -->
    <div id="home">
		<?php if($redux_iwebtheme['intro-bg-image']['url'] != '') { ?>
			<div class="section-overlay"></div>
		<?php } ?>
		<?php if($redux_iwebtheme['intro-bg-image']['url'] == '' && $redux_iwebtheme['intro-bg-color'] !='' ) { ?>
			 <div class="solid-bg-color"></div>
		<?php } ?>
       

        <!-- start sticky header -->
        <div id="header"> 
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">

                        <!-- start logo navigation bar --> 
						
                        <div id="logo-small">
							<?php if($redux_iwebtheme['main-logo']['url'] != '') { ?>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo $redux_iwebtheme['main-logo']['url']; ?>" alt="" width="<?php echo $redux_iwebtheme['main-logo-w']; ?>" height="<?php echo $redux_iwebtheme['main-logo-h']; ?>" /></a>					
							<?php } else { ?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-small@2x.png" alt="" width="89" height="36" /></a>	
							<?php } ?>
                        </div>
						
						
                        <!-- end logo navigation bar -->
						
						<?php
						wp_nav_menu(array(
						'menu_id' => 'nav', 
						'menu_class' => '', 
						'container' => false, 	
						'theme_location' => 'main',
						'fallback_cb' => false, 
						'depth' => 1
						));
						?>	


                        <div id="nav-toggle">
                            <i class="fa fa-bars"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end sticky header -->

		<?php if(is_page_template('page-home.php')) { 
			get_template_part( 'includes/section-header');
		}
		?>

    </div>
    <!-- end home -->