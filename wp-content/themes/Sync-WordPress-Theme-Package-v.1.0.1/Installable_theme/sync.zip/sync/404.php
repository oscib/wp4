<?php
/**
 * @package WordPress
 * @subpackage Sync Theme
 */
?>
<?php get_header(); ?>
<?php get_template_part( 'includes/section-inner-heading'); ?>
<section id="main-content" class="inner">
  	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-12" >

					<h2 class="aligncenter"><?php echo __('Sorry your requested page does not exist','iwebtheme'); ?></h2>

			</div>
		</div>
	</div>
</section> 
<?php get_footer(); ?>