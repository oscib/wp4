<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package Sync
 */
?>
<div class="col-md-4">
	<div class="sidebar">
    <?php dynamic_sidebar('Primary Sidebar'); ?>
	</div>
</div><!-- #secondary -->
