<?php
/**
 *
 * @package Sync
 */
get_header(); ?>
<?php get_template_part( 'includes/section-inner-heading'); ?>
<section id="main-content">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
		<?php if ( have_posts() ) : ?>

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', get_post_format() ); ?>

			<?php endwhile; ?>
			<?php if (function_exists("pagination")) { 
			 pagination();
			} else {
			posts_nav_link(' &#183; ', 'previous page', 'next page'); 	
			} ?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
</section><!-- #primary -->

<?php get_footer(); ?>
