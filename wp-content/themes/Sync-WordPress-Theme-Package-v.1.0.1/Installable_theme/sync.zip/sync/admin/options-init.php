<?php
if (!class_exists('sync_Redux_Framework_config')) {

    class sync_Redux_Framework_config {

        public $args        = array();
        public $sections    = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {

            if (!class_exists('ReduxFramework')) {
                return;
            }

            // This is needed. Bah WordPress bugs.  ;)
            if ( true == Redux_Helpers::isTheme( __FILE__ ) ) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);
            }

        }

        public function initSettings() {

            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            // If Redux is running as a plugin, this will remove the demo notice and links
            add_action( 'redux/loaded', array( $this, 'remove_demo' ) );
            
            // Function to test the compiler hook and demo CSS output.
            // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
            //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 2);
            
            // Change the arguments after they've been declared, but before the panel is created
            //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );
            
            // Change the default value of a field after it's been set, but before it's been useds
            //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );
            
            // Dynamically add a section. Can be also used to modify sections/fields
            //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        /**

          This is a test function that will let you see when the compiler hook occurs.
          It only runs if a field	set with compiler=>true is changed.

         * */
        function compiler_action($options, $css) {
            //echo '<h1>The compiler hook has run!';
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

            /*
              // Demo of how to use the dynamic CSS and write your own static CSS file
              $filename = dirname(__FILE__) . '/style' . '.css';
              global $wp_filesystem;
              if( empty( $wp_filesystem ) ) {
                require_once( ABSPATH .'/wp-admin/includes/file.php' );
              WP_Filesystem();
              }

              if( $wp_filesystem ) {
                $wp_filesystem->put_contents(
                    $filename,
                    $css,
                    FS_CHMOD_FILE // predefined mode settings for WP files
                );
              }
             */
        }

        /**

          Custom function for filtering the sections array. Good for child themes to override or add to the sections.
          Simply include this function in the child themes functions.php file.

          NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
          so you must use get_template_directory_uri() if you want to use any of the built in icons

         * */
        function dynamic_section($sections) {
            //$sections = array();
            $sections[] = array(
                'title' => __('Section via hook', 'iwebtheme'),
                'desc' => __('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'iwebtheme'),
                'icon' => 'el-icon-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }

        /**

          Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.

         * */
        function change_arguments($args) {
            //$args['dev_mode'] = true;

            return $args;
        }

        /**

          Filter hook for filtering the default value of any given field. Very useful in development mode.

         * */
        function change_defaults($defaults) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }

        // Remove the demo link and the notice of integrated demo from the redux-framework plugin
        function remove_demo() {

            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if (class_exists('ReduxFrameworkPlugin')) {
                remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), null, 2);

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
            }
        }

        public function setSections() {

            /**
              Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
             * */
            // Background Patterns Reader
            $sample_patterns_path   = ReduxFramework::$_dir . '../sample/patterns/';
            $sample_patterns_url    = ReduxFramework::$_url . '../sample/patterns/';
            $sample_patterns        = array();

            if (is_dir($sample_patterns_path)) :

                if ($sample_patterns_dir = opendir($sample_patterns_path)) :
                    $sample_patterns = array();

                    while (( $sample_patterns_file = readdir($sample_patterns_dir) ) !== false) {

                        if (stristr($sample_patterns_file, '.png') !== false || stristr($sample_patterns_file, '.jpg') !== false) {
                            $name = explode('.', $sample_patterns_file);
                            $name = str_replace('.' . end($name), '', $sample_patterns_file);
                            $sample_patterns[]  = array('alt' => $name, 'img' => $sample_patterns_url . $sample_patterns_file);
                        }
                    }
                endif;
            endif;

            ob_start();

            $ct             = wp_get_theme();
            $this->theme    = $ct;
            $item_name      = $this->theme->get('Name');
            $tags           = $this->theme->Tags;
            $screenshot     = $this->theme->get_screenshot();
            $class          = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(__('Customize &#8220;%s&#8221;', 'iwebtheme'), $this->theme->display('Name'));
            
            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
                <?php endif; ?>

                <h4><?php echo $this->theme->display('Name'); ?></h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(__('By %s', 'iwebtheme'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(__('Version %s', 'iwebtheme'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . __('Tags', 'iwebtheme') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description"><?php echo $this->theme->display('Description'); ?></p>
            <?php
            if ($this->theme->parent()) {
                printf(' <p class="howto">' . __('This <a href="%1$s">child theme</a> requires its parent theme, %2$s.') . '</p>', __('http://codex.wordpress.org/Child_Themes', 'iwebtheme'), $this->theme->parent()->display('Name'));
            }
            ?>

                </div>
            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();

            $sampleHTML = '';
            if (file_exists(dirname(__FILE__) . '/info-html.html')) {
                /** @global WP_Filesystem_Direct $wp_filesystem  */
                global $wp_filesystem;
                if (empty($wp_filesystem)) {
                    require_once(ABSPATH . '/wp-admin/includes/file.php');
                    WP_Filesystem();
                }
                $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
            }

            // ACTUAL DECLARATION OF SECTIONS
            $this->sections[] = array(
                'icon'      => 'el-icon-cogs',
                'title'     => __('General Settings', 'iwebtheme'),
                'fields'    => array(
				
					array(
                        'id'        => 'main-logo',
                        'type'      => 'media',
                        'url'       => true,
                        'title'     => __('Site logo', 'iwebtheme'),
                        'compiler'  => 'true',
                        //'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc'      => __('', 'iwebtheme'),
                        'subtitle'  => __('Let\'s say you have a logo which is 89 x 36. The retina logo would be 178 x 72', 'iwebtheme'),
                        'default'   => array('url' => ''),
                        //'hint'      => array(
                        //    'title'     => 'Hint Title',
                        //    'content'   => 'This is a <b>hint</b> for the media field with a Title.',
                        //)
                    ),
					
					array(
                        'id'        => 'main-logo-w',
                        'type'      => 'text',
                        'title'     => __('Logo width', 'iwebtheme'),
						'default'   => '',
                        'desc'      => 'your logo width, enter half of uploaded logo width',
                    ),
					
					array(
                        'id'        => 'main-logo-h',
                        'type'      => 'text',
                        'title'     => __('Logo height', 'iwebtheme'),
						'default'   => '',
                        'desc'      => 'your logo height, enter half of uploaded logo height',
                    ),

                    array(
                        'id'        => 'opt-analytics',
                        'type'      => 'textarea',
                        'title'     => __('Tracking Code', 'iwebtheme'),
                        'subtitle'  => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.', 'iwebtheme'),
                        'validate'  => 'js',
						'default'   => '',
                        'desc'      => 'Validate that it\'s javascript!',
                    ),
					array(
						'id'       => 'opt-footertext',
						'type'     => 'text',
						'title'    => __('Footer copyright text', 'iwebtheme'),
						'default'  => '&copy;Copyright 2014 - Sync. All rights reserved.'
					),

                )
            );

			//homepage
            $this->sections[] = array(
                'icon'      => 'el-icon-cogs',
                'title'     => __('Home one page headers', 'iwebtheme'),
                'fields'    => array(
				
					array(
                        'id'        => 'feat-intro-logo',
                        'type'      => 'section',
                        'title'     => __('Intro logo', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
				
				
					array(
                        'id'        => 'lp-logo',
                        'type'      => 'media',
                        'url'       => true,
                        'title'     => __('Intro logo', 'iwebtheme'),
                        'compiler'  => 'true',
                        //'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc'      => __('', 'iwebtheme'),
                        'subtitle'  => __('Let\'s say you have a logo which is 175 x 70. The retina logo would be 350 x 140', 'iwebtheme'),
                        'default'   => array('url' => ''),
                        //'hint'      => array(
                        //    'title'     => 'Hint Title',
                        //    'content'   => 'This is a <b>hint</b> for the media field with a Title.',
                        //)
                    ),
					
					array(
                        'id'        => 'lp-logo-w',
                        'type'      => 'text',
                        'title'     => __('Logo width', 'iwebtheme'),
						'default'   => '',
                        'desc'      => 'your logo width, enter half of uploaded logo width',
                    ),
					
					array(
                        'id'        => 'lp-logo-h',
                        'type'      => 'text',
                        'title'     => __('Logo height', 'iwebtheme'),
						'default'   => '',
                        'desc'      => 'your logo height, enter half of uploaded logo height',
                    ),
				
					array(
                        'id'        => 'feat-intro-background',
                        'type'      => 'section',
                        'title'     => __('Intro background', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
				
					array(
                        'id'        => 'intro-bg-color',
                        'type'      => 'color',
                        'title'     => __('Intro Background Color', 'iwebtheme'),
                        'subtitle'  => __('Pick a background color for the intro (default: #50449a).', 'iwebtheme'),
						'transparent'   => false,
                        'default'   => '#50449a',
                        'validate'  => 'color',
                    ),
					
                    array(
                        'id'        => 'intro-bg-image',
                        'type'      => 'media',
                        'url'       => true,
                        'title'     => __('Background image', 'iwebtheme'),
                        'compiler'  => 'true',
                        //'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc'      => __('', 'iwebtheme'),
                        'subtitle'  => __('Upload your image using WordPress native uploader', 'iwebtheme'),
                        'default'   => array('url' => ''),
                        //'hint'      => array(
                        //    'title'     => 'Hint Title',
                        //    'content'   => 'This is a <b>hint</b> for the media field with a Title.',
                        //)
                    ),
				
					array(
                        'id'        => 'feat-home-intro-content',
                        'type'      => 'section',
                        'title'     => __('Intro image', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
					 array(
                        'id'        => 'intro-product-image',
                        'type'      => 'media',
                        'url'       => true,
                        'title'     => __('Product image', 'iwebtheme'),
                        'compiler'  => 'true',
                        //'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc'      => __('', 'iwebtheme'),
                        'subtitle'  => __('Upload your image using WordPress native uploader', 'iwebtheme'),
                        'default'   => array('url' => ''),
                        //'hint'      => array(
                        //    'title'     => 'Hint Title',
                        //    'content'   => 'This is a <b>hint</b> for the media field with a Title.',
                        //)
                    ),
					
					
				
					array(
                        'id'        => 'feat-home-intro-content',
                        'type'      => 'section',
                        'title'     => __('Intro content', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
					
					array(
						'id'	=> 'intro-lptitle',
						'type' 	=> 'multi_text',
						'title' => __('Intro slogan / title', 'iwebtheme'),
						'subtitle' => __('Sliding title', 'iwebtheme'),
						'default'   => array(
								0 => 'Sync was designed to become',
								1 => 'Your perfect landing page'
							),
						
						'desc' => __('Entered title above will be displayed in a text slide', 'iwebtheme')
					),
										
					array(
						'id'       => 'intro-subtitle',
						'type'     => 'textarea',
						'title'    => __('Intro subtitle', 'iwebtheme'),
						'default'  => 'Etiam ullamcorper et turpis eget hendrerit. Praesent varius risus mi, at elementum magna ultricies accumsan. Cras venenatis lacus sed dolor placerat tempus. Morbi blandit at neque ut imperdiet. '
					),
					
					
					array(
						'id'       => 'intro-button1-txt',
						'type'     => 'text',
						'title'    => __('CTA button 1 text', 'iwebtheme'),
						'default'  => 'Download',
						'desc'      => __('Enter CTA button 1 text', 'iwebtheme'),
					),
					array(
						'id'       => 'intro-button1',
						'type'     => 'text',
						'title'    => __('CTA button 1 URL or targeted section ID', 'iwebtheme'),
						'default'  => '',
						'desc'      => __('You can put targeted section ID e.g #about', 'iwebtheme'),
					),
					array(
						'id'       => 'intro-button2-txt',
						'type'     => 'text',
						'title'    => __('CTA button 2 text', 'iwebtheme'),
						'default'  => 'Learn more',
						'desc'      => __('Enter CTA button 2 text', 'iwebtheme'),
					),
					array(
						'id'       => 'intro-button2',
						'type'     => 'text',
						'title'    => __('CTA button 2 URL or targeted section ID', 'iwebtheme'),
						'default'  => '',
						'desc'      => __('You can put targeted section ID e.g #about', 'iwebtheme'),
					),
					
					array(
						'id'       => 'intro-os1',
						'type'     => 'text',
						'title'    => __('Apple store link', 'iwebtheme'),
						'default'  => '',
						'desc'      => __('Leave this blank to disable apple store link', 'iwebtheme'),
					),
					array(
						'id'       => 'intro-os2',
						'type'     => 'text',
						'title'    => __('Android store link', 'iwebtheme'),
						'default'  => '',
						'desc'      => __('Leave this blank to disable android store link', 'iwebtheme'),
					),
					array(
						'id'       => 'intro-os3',
						'type'     => 'text',
						'title'    => __('Windows store link', 'iwebtheme'),
						'default'  => '',
						'desc'      => __('Leave this blank to disable windows mobile store link', 'iwebtheme'),
					),



                )
            );
			
			//Footer
            $this->sections[] = array(
                'icon'      => 'el-icon-cogs',
                'title'     => __('Footer', 'iwebtheme'),
                'fields'    => array(
				
					array(
                        'id'        => 'footer-social-icons',
                        'type'      => 'section',
                        'title'     => __('Footer social links', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
					array(
						'id'       => 'footer-facebook',
						'type'     => 'text',
						'title'    => __('Facebook', 'iwebtheme'),
						'default'  => 'https://facebook.com'
					),
					array(
						'id'       => 'footer-gplus',
						'type'     => 'text',
						'title'    => __('Google plus', 'iwebtheme'),
						'default'  => 'https://plus.google.com'
					),
					array(
						'id'       => 'footer-twitter',
						'type'     => 'text',
						'title'    => __('Twitter', 'iwebtheme'),
						'default'  => 'https://twitter.com'
					),
					
					array(
						'id'       => 'footer-dribbble',
						'type'     => 'text',
						'title'    => __('Dribbble', 'iwebtheme'),
						'default'  => 'https://dribbble.com'
					),
					array(
						'id'       => 'footer-flickr',
						'type'     => 'text',
						'title'    => __('Flickr', 'iwebtheme'),
						'default'  => 'https://flickr.com'
					),

                )
            );
			
            $this->sections[] = array(
                'icon'      => 'el-icon-website',
                'title'     => __('Styling Options', 'iwebtheme'),
                'fields'    => array(
                    array(
                        'id'        => 'opt-select-stylesheet',
                        'type'      => 'select',
                        'title'     => __('Theme Stylesheet', 'iwebtheme'),
                        'subtitle'  => __('Select your themes alternative color scheme.', 'iwebtheme'),
                        'options'   => array('color-concrete.css' => 'concrete','color-crimson.css' => 'crimson','color-darkturquoise.css' => 'darkturquoise', 'color-dodgerblue.css' => 'dodgerblue', 'color-emerald.css' => 'emerald', 'color-redorange.css' => 'redorange'),
                        'default'   => 'concrete',
                    ),

                    array(
                        'id'        => 'opt-color-footerbg',
                        'type'      => 'color',
                        'title'     => __('Footer Background Color', 'iwebtheme'),
                        'subtitle'  => __('Pick a background color for the footer (default: #1c1c1c).', 'iwebtheme'),
                        'default'   => '#1c1c1c',
                        'validate'  => 'color',
                    ),

					
                    array(
                        'id'        => 'opt-typography-body',
                        'type'      => 'typography',
                        'title'     => __('#1 Font', 'iwebtheme'),
                        'subtitle'  => __('Body content', 'iwebtheme'),
                        'google'    => true,
						'text-align'   => false,
						'line-height'     => false,
						'subsets'     => false,
						'font-size'     => false,
						'color'     => false,
                        'default'   => array(
							'google'      => true,
                            'font-family'   => 'Open Sans',
                            'font-weight'   => '400',
                        ),
						'preview'  => array(
							'always_display'   => true,
						),
                    ),
					
					array(
                        'id'        => 'opt-typography-heading',
                        'type'      => 'typography',
                        'title'     => __('#2 Font', 'iwebtheme'),
                        'subtitle'  => __('Heading content.', 'iwebtheme'),
                        'google'    => true,
						'text-align'   => false,
						'line-height'     => false,
						'subsets'     => false,
						'font-size'     => false,
						'color'     => false,
                        'default'   => array(
							'google'      => true,
                            'font-family'   => 'Open Sans',
                            'font-weight'   => '400',
                        ),
						'preview'  => array(
							'always_display'   => true,
						),
                    ),

					
					
                    array(
                        'id'        => 'opt-custom-css',
                        'type'      => 'textarea',
                        'title'     => __('Custom CSS', 'iwebtheme'),
                        'subtitle'  => __('Quickly add some CSS to your theme by adding it to this block.', 'iwebtheme'),
                        'desc'      => __('This field is even CSS validated!', 'iwebtheme'),
						'default'   => '',
                        'validate'  => 'css',
                    ),
                )
            );
			
			//contact
            $this->sections[] = array(
                'icon'      => 'el-icon-cogs',
                'title'     => __('Contact Settings', 'iwebtheme'),
                'fields'    => array(
				
					array(
						'id'       => 'opt-emailaddress',
						'type'     => 'text',
						'validate'  => 'email',
						'title'    => __('Your email address', 'iwebtheme'),
						'default'  => 'name@email.com'
					),
					array(
						'id'       => 'opt-emailsubject',
						'type'     => 'text',
						'title'    => __('Email subject', 'iwebtheme'),
						'default'  => 'Rapid theme contact form'
					),
					array(
						'id'       => 'opt-emailsuccess',
						'type'     => 'textarea',
						'title'    => __('Email success message', 'iwebtheme'),
						'default'  => 'Thanks for your message! We\'ll contact you back as soon as it is possible.'
					),
					
					array(
						'id'       => 'opt-contacterror',
						'type'     => 'textarea',
						'title'    => __('Contact error message title', 'iwebtheme'),
						'default'  => 'Your message has not been sent due to following errors:'
					),
					
					array(
						'id'       => 'opt-nameerror',
						'type'     => 'text',
						'title'    => __('name field error', 'iwebtheme'),
						'default'  => 'Please enter your name'
					),
					array(
						'id'       => 'opt-emailerror',
						'type'     => 'text',
						'title'    => __('email field error', 'iwebtheme'),
						'default'  => 'Please enter your email'
					),
					array(
						'id'       => 'opt-messageerror',
						'type'     => 'text',
						'title'    => __('Message field error', 'iwebtheme'),
						'default'  => 'Please enter your message'
					),
					
					array(
                        'id'        => 'section-widget-start',
                        'type'      => 'section',
                        'title'     => __('Contact info 1', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
					array(
						'id'       => 'opt-cw1-title',
						'type'     => 'text',
						'title'    => __('Contact widget heading', 'iwebtheme'),
						'default'  => 'Need Help?'
					),
					
					array(
						'id'       => 'opt-cw1-text',
						'type'     => 'textarea',
						'title'    => __('Contact widget text', 'iwebtheme'),
						'default'  => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad'
					),
					array(
                        'id'        => 'section-widget-start',
                        'type'      => 'section',
                        'title'     => __('Contact info 2', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
					array(
						'id'       => 'opt-cw2-title',
						'type'     => 'text',
						'title'    => __('Contact widget heading', 'iwebtheme'),
						'default'  => 'Our Location'
					),
					
					array(
						'id'       => 'opt-cw2-text',
						'type'     => 'textarea',
						'title'    => __('Contact widget text', 'iwebtheme'),
						'default'  => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.'
					),
					array(
                        'id'        => 'section-widget-start',
                        'type'      => 'section',
                        'title'     => __('Contact info 3', 'iwebtheme'),
                        'indent'    => true // Indent all options below until the next 'section' option is set.
                    ),
					array(
						'id'       => 'opt-cw3-title',
						'type'     => 'text',
						'title'    => __('Contact widget heading', 'iwebtheme'),
						'default'  => 'Call Us!'
					),
					
					array(
						'id'       => 'opt-cw3-text',
						'type'     => 'text',
						'title'    => __('Contact widget text', 'iwebtheme'),
						'default'  => '123 45 67 89'
					),
					


                )
            );
			



            $theme_info  = '<div class="redux-framework-section-desc">';
            $theme_info .= '<p class="redux-framework-theme-data description theme-uri">' . __('<strong>Theme URL:</strong> ', 'iwebtheme') . '<a href="' . $this->theme->get('ThemeURI') . '" target="_blank">' . $this->theme->get('ThemeURI') . '</a></p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-author">' . __('<strong>Author:</strong> ', 'iwebtheme') . $this->theme->get('Author') . '</p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-version">' . __('<strong>Version:</strong> ', 'iwebtheme') . $this->theme->get('Version') . '</p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-description">' . $this->theme->get('Description') . '</p>';
            $tabs = $this->theme->get('Tags');
            if (!empty($tabs)) {
                $theme_info .= '<p class="redux-framework-theme-data description theme-tags">' . __('<strong>Tags:</strong> ', 'iwebtheme') . implode(', ', $tabs) . '</p>';
            }
            $theme_info .= '</div>';


            


            $this->sections[] = array(
                'title'     => __('Import / Export', 'iwebtheme'),
                'desc'      => __('Import and Export your Redux Framework settings from file, text or URL.', 'iwebtheme'),
                'icon'      => 'el-icon-refresh',
                'fields'    => array(
                    array(
                        'id'            => 'opt-import-export',
                        'type'          => 'import_export',
                        'title'         => 'Import Export',
                        'subtitle'      => 'Save and restore your Redux options',
                        'full_width'    => false,
                    ),
                ),
            );                     
                    
            $this->sections[] = array(
                'type' => 'divide',
            );


        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-1',
                'title'     => __('Theme Information 1', 'iwebtheme'),
                'content'   => __('<p>This is the tab content, HTML is allowed.</p>', 'iwebtheme')
            );

            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-2',
                'title'     => __('Theme Information 2', 'iwebtheme'),
                'content'   => __('<p>This is the tab content, HTML is allowed.</p>', 'iwebtheme')
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'iwebtheme');
        }

        /**

          All the possible arguments for Redux.
          For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments

         * */
        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                'opt_name' => 'redux_iwebtheme',
                'page_slug' => '_options',
                'page_title' => 'Theme Options',
                'dev_mode' => '1',
                'update_notice' => '1',
                'intro_text' => '<p>For more information about author & product please visit http://iweb-studio.com</p>',
                'footer_text' => '',
                'admin_bar' => '1',
                'menu_type' => 'menu',
                'menu_title' => 'Theme Options',
                'allow_sub_menu' => '1',
                'page_parent_post_type' => 'your_post_type',
                'customizer' => '1',
                'hints' => 
                array(
                  'icon' => 'el-icon-question-sign',
                  'icon_position' => 'right',
                  'icon_size' => 'normal',
                  'tip_style' => 
                  array(
                    'color' => 'light',
                  ),
                  'tip_position' => 
                  array(
                    'my' => 'top left',
                    'at' => 'bottom right',
                  ),
                  'tip_effect' => 
                  array(
                    'show' => 
                    array(
                      'duration' => '500',
                      'event' => 'mouseover',
                    ),
                    'hide' => 
                    array(
                      'duration' => '500',
                      'event' => 'mouseleave unfocus',
                    ),
                  ),
                ),
                'output' => '1',
                'output_tag' => '1',
                'compiler' => '1',
                'page_icon' => 'icon-themes',
                'page_permissions' => 'manage_options',
                'save_defaults' => '1',
                'show_import_export' => '1',
                'transient_time' => '3600',
                'network_sites' => '1',
              );

            $theme = wp_get_theme(); // For use with some settings. Not necessary.
            $this->args["display_name"] = $theme->get("Name");
            $this->args["display_version"] = $theme->get("Version");

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.

            $this->args['share_icons'][] = array(
                'url'   => 'https://www.facebook.com/iWebStudioTheme',
                'title' => 'Like us on Facebook',
                'icon'  => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url'   => 'http://twitter.com/iWebStudio',
                'title' => 'Follow us on Twitter',
                'icon'  => 'el-icon-twitter'
            );
        }

    }
    
    global $reduxConfig;
    $reduxConfig = new sync_Redux_Framework_config();
}

/**
  Custom function for the callback referenced above
 */
if (!function_exists('sync_my_custom_field')):
    function sync_my_custom_field($field, $value) {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
endif;

/**
  Custom function for the callback validation referenced above
 * */
if (!function_exists('sync_validate_callback_function')):
    function sync_validate_callback_function($field, $value, $existing_value) {
        $error = false;
        $value = 'just testing';

        /*
          do your validation

          if(something) {
            $value = $value;
          } elseif(something else) {
            $error = true;
            $value = $existing_value;
            $field['msg'] = 'your custom error message';
          }
         */

        $return['value'] = $value;
        if ($error == true) {
            $return['error'] = $field;
        }
        return $return;
    }
endif;
