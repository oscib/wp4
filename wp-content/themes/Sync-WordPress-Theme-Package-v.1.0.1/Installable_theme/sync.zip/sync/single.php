<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Sync
 */

get_header(); ?>
<?php get_template_part( 'includes/section-inner-heading'); ?>
<section id="main-content" class="inner">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'content', get_post_format() ); 
					sync_post_nav();
					?>
				<?php endwhile; ?>
				<?php else : ?>
					<?php get_template_part( 'content', 'none' ); ?>
				<?php endif; ?>
				<?php comments_template(); ?>
			</div>
			<?php get_sidebar(); ?>	
		</div>
	</div><!-- #main -->
</section><!-- #primary -->


<?php get_footer(); ?>