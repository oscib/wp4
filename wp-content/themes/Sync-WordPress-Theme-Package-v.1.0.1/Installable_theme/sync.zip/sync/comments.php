<?php
	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

	if ( post_password_required() ) { ?>
		<p class="nocomments"><?php _e('This post is password protected. Enter the password to view comments.','iwebtheme'); ?></p>
	<?php
		return;
	}
?>
<div id="comments" class="post-comments">

<?php if ( comments_open() ) : ?>
    <h3 class="marginbot-50"><?php comments_number(__('0 Comments', 'iwebtheme'), __('1 Comment', 'iwebtheme'), __('% Comments', 'iwebtheme') );?></h3>

<?php if ( have_comments() ) : ?>

<ul class="comment-list">
	<?php wp_list_comments( array( 'callback' => 'custom_comments', 'style' => 'ul', 'avatar_size' => '80' ) ); ?>
</ul>


<div class="comment-nav">
	<div class="alignleft"><?php previous_comments_link() ?></div>
	<div class="alignright"><?php next_comments_link() ?></div>
</div>


<?php endif; ?>
<?php else :
// comments are closed ?>
<?php endif; ?>


<?php if ( comments_open() ) : ?>

<?php if ( get_option('comment_registration') && !is_user_logged_in() ) : ?>
<p><?php _e('You must be','iwebtheme'); ?> <a href="<?php echo wp_login_url( get_permalink() ); ?>"><?php _e('logged in','iwebtheme'); ?></a><?php _e(' to post a comment.','iwebtheme'); ?></p>

<?php else : ?>
<div id="respond">

<h3><?php _e('Leave a comment','iwebtheme') ?></h3>

<?php cancel_comment_reply_link(); ?>

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post">
<?php if ( is_user_logged_in() ) : ?>
<p class="loggedin"><?php _e('Logged in as','iwebtheme'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="<?php _e('Log out of this account','iwebtheme'); ?>"><?php _e('Log out','iwebtheme'); ?> &raquo;</a></p>

<?php else : ?>

	<div class="row">
		<div class="col-md-6">
			<input type="text" name="author" class="form-control input-md" id="username" placeholder="<?php echo __('Enter name','iwebtheme'); ?>" required="required" />
		</div>
		<div class="col-md-6">
			<input type="email" name="email" id="email" class="form-control input-md" placeholder="<?php echo __('Enter email','iwebtheme'); ?>" required="required" />
		</div>
	</div>

<?php endif; ?>
	<div class="row">
		<div class="col-md-12">
			<div class="form-group">
				<textarea name="comment" id="message" class="form-control" rows="4" cols="25" required="required" 
											placeholder="<?php echo __('Comment','iwebtheme'); ?>"></textarea>
			</div>						
			<button type="submit" class="btn btn-primary btn-md">
			<?php echo __('Submit comment','iwebtheme'); ?></button>
			</div>
	</div>
	

<?php comment_id_fields(); ?>
<?php do_action('comment_form', $post->ID); ?>
</form>
</div>
<!-- end row -->
<?php endif;
// registration required and not logged in ?>

<?php else :
comment_form();
// comments are closed ?>
<?php endif;
// delete me and the sky will fall on your brain ?>
</div>