<?php
/*
Template Name: Home one page
*/
global $home_query,$homesec_class; 
get_header(); 
?>
<?php get_header(); ?>
<?php
	$page_sort_sections = iwebtheme_sort_sections();
	$args = array(
		'posts_per_page' => -1,
		'post_type' => 'homepagesection',
		'order' => 'ASC',
		);
	$home_query = new WP_Query($args);  

	if($home_query->have_posts()):  while($home_query->have_posts()) : $home_query->the_post();	
		$homesec_class = get_post_type();
		get_template_part('includes/section-home');
		endwhile;
	else:
		get_template_part( 'no-results', 'home' );
	endif;
?>
<!--end content-->
<?php get_footer(); ?>