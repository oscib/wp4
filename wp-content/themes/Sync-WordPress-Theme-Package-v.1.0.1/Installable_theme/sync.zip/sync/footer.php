<?php
global $redux_iwebtheme;
/**
 *
 * @package Sync
 */
?>
    <!-- start footer -->
    <div id="footer" class="offsetTopS offsetBottomS text-center">
        <div class="container">

            <div class="row padding-b5">
                <div class="col-sm-12">
                    <ul class="social-icons text-center">
						<?php if($redux_iwebtheme['footer-facebook'] != '') { ?>
                        <li class="facebook"><a href="<?php echo $redux_iwebtheme['footer-facebook']; ?>"><i class="fa fa-facebook"></i></a></li>
						<?php } ?>
						<?php if($redux_iwebtheme['footer-gplus'] != '') { ?>
                        <li class="googleplus"><a href="<?php echo $redux_iwebtheme['footer-gplus']; ?>"><i class="fa fa-google-plus"></i></a></li>
						<?php } ?>
						<?php if($redux_iwebtheme['footer-twitter'] != '') { ?>
                        <li class="twitter"><a href="<?php echo $redux_iwebtheme['footer-twitter']; ?>"><i class="fa fa-twitter"></i></a></li>
						<?php } ?>
						<?php if($redux_iwebtheme['footer-dribbble'] != '') { ?>
                        <li class="dribbble"><a href="<?php echo $redux_iwebtheme['footer-dribbble']; ?>"><i class="fa fa-dribbble"></i></a></li>
						<?php } ?>
						<?php if($redux_iwebtheme['footer-flickr'] != '') { ?>
                        <li class="flickr"><a href="<?php echo $redux_iwebtheme['footer-flickr']; ?>"><i class="fa fa-flickr"></i></a></li>
						<?php } ?>
                    </ul>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
				<?php
					wp_nav_menu(array(
						'menu_class' => 'footer-links',
						'container' => false, 	
						'theme_location' => 'footer',	
						'fallback_cb' => false, 						
						'depth' => 0
					));
				?>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
				<?php if($redux_iwebtheme['opt-footertext'] != '') { ?>	
				<div class="copyright"><?php echo $redux_iwebtheme['opt-footertext']; ?></div>
				<?php } else { ?>
                    <div class="copyright"><?php echo __('&copy;2014 Sync. All rights reserved.', 'iwebtheme'); ?></div>
				<?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php if($redux_iwebtheme['opt-analytics'] != '') {
echo $redux_iwebtheme['opt-analytics']; 
} ?>
<?php wp_footer(); ?>
</body>
</html>
