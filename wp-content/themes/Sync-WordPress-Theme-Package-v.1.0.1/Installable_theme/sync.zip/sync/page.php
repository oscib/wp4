<?php
/**
 *
 * @package Sync
 */
get_header(); ?>
<?php get_template_part( 'includes/section-inner-heading'); ?>
<section id="main-content" class="inner">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

					<h3 class="inner-title"><?php the_title(); ?></h3>
					<?php
						
						the_content();
						wp_link_pages( array(
							'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'iwebtheme' ) . '</span>',
							'after'       => '</div>',
							'link_before' => '<span>',
							'link_after'  => '</span>',
						) );
					?>

				</article>
			<?php endwhile; endif; ?>
			<?php comments_template(); ?>	
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div><!-- #main -->
</section><!-- #primary -->
<?php get_footer(); ?>
